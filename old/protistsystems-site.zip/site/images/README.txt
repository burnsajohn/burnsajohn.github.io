Put figures, headshots, and the favicon here.
